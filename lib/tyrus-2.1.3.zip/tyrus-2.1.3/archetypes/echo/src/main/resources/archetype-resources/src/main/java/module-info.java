module $package {
    requires jakarta.websocket.client;
    requires jakarta.websocket;

    exports $package;
}